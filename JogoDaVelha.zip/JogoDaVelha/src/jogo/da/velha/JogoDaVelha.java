package jogo.da.velha;

import java.util.Scanner;

public class JogoDaVelha {
	Campo[][] velha = new Campo[3][3];
	char simboloAtual='x';
	boolean game=true;
	String vitoria="";
	Scanner scan = new Scanner(System.in);
}
